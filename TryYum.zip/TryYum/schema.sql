use truyum;


CREATE TABLE truyum_userr (
  [user_id] INT identity PRIMARY KEY,
  [user_name] VARCHAR(60)
  );

CREATE TABLE menu_itemm (
  menu_id INT identity PRIMARY KEY ,
  menu_name VARCHAR(100) ,
  menu_price DECIMAL(8,2) ,
  menu_active VARCHAR(10) ,
  menu_dol DATE ,
  menu_category VARCHAR(45) ,
  menu_free_delivery VARCHAR(10) 
  );
  
CREATE TABLE cart (
  cart_id INT PRIMARY KEY,
  [user_id] INT ,
  menu_id INT ,
  
  FOREIGN KEY (user_id) REFERENCES truyum_userr (user_id),
  FOREIGN KEY (menu_id) REFERENCES menu_itemm (menu_id)
    );

	