use truyum;
-- 1 Inset into menu item--
insert into menu_itemm (menu_name,menu_price,menu_active,menu_dol,menu_category,menu_free_delivery) 
values('Sandwich',99.00,'Yes','2017-05-13','Main Course','Yes'),
('Burger',129.00,'Yes','2017-12-23','Main Course','No'),
('Pizza',149.00,'Yes','2017-08-21','Main Course','No'),
('French Fries',57.00,'No','2017-07-02','Starters','Yes'),
('Chocolate Brownie',32.00,'Yes','2022-11-02','Dessert','Yes');

-- 1 b. get all items
select * from menu_itemm;
-- 2   example date of launch
select * from menu_itemm where menu_dol<getdate() and menu_active = 'Yes';
-- 3  a. 
select * from menu_itemm where menu_id = '8003';
-- 3 b.
update menu_itemm 
set menu_name='Steak',menu_price='375.00',menu_active='Yes',menu_dol='2020-07-22',menu_category='Main Course',menu_free_delivery= 'Yes'
where menu_id = '1';
-- 4 a 
insert into truyum_userr(user_name) 
values('Satyajit'),
	  ('Jagannath');
select * from truyum_userr;
select * from cart;
truncate table cart;
insert into cart(cart_id,user_id,menu_id) values(1,1,1),(2,1,2),(3,1,3);
-- 5 a
select 
		m.menu_name,
        m.menu_free_delivery,
        m.menu_price 
	from menu_itemm m
inner join cart c on m.menu_id=c.menu_id
inner join truyum_userr u on c.user_id=u.user_id
		where c.user_id=1;
-- 5 b 
select 
		concat('Rs. ',cast(sum(m.menu_price)as char)) as Total 
	from menu_item m
inner join truyum_cart c on m.menu_id=c.menu_id
inner join truyum_user u on c.user_id=u.user_id
		where c.user_id=1;
-- 6 
Delete from cart where [user_id] = 1 and menu_id = 3;